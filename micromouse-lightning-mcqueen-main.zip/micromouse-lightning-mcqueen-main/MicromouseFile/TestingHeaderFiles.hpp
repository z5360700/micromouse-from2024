//////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Motor.hpp
    // MOTOR SPEED AND DIRECTION TEST
    // int speed = 200;
    
    // motor.setPWM(speed);
    // Serial.print("Speed is: ");
    // Serial.println(speed);
    // delay(1000);

    // motor.setPWM(0);
    // Serial.print("Speed is: ");
    // Serial.println(0);
    // delay(2000);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // ThreeLidar.hpp
// void loop() {
//     int distanceLeft = lidar.readLeftSensor();
//     int distanceForward = lidar.readForwardSensor();
//     int distanceRight = lidar.readRightSensor();
    
//     Serial.print("SensorLeft 1: ");
//     Serial.print(distanceLeft);
//     Serial.print(" mm | SensorForward 2: ");
//     Serial.print(distanceForward);
//     Serial.print(" mm | SensorRight 3: ");
//     Serial.print(distanceRight);
//     Serial.println(" mm");
    
//     if (lidar.timeoutOccurredSensor1()) { Serial.println("Sensor 1 TIMEOUT"); }
//     if (lidar.timeoutOccurredSensor2()) { Serial.println("Sensor 2 TIMEOUT"); }
//     if (lidar.timeoutOccurredSensor3()) { Serial.println("Sensor 3 TIMEOUT"); }
    
//     delay(25);
// }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // delay(50);
    // encoder_odometry.update(encoder.getLeftRotation(),encoder.getRightRotation());
    // Serial.print("ODOM:\t\t");
    // Serial.print(encoder_odometry.getX());
    // Serial.print(",\t\t");
    // Serial.print(encoder_odometry.getY());
    // Serial.print(",\t\t");
    // Serial.print(encoder_odometry.getH());
    // Serial.println();

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //  // Print current encoder values for debugging
    //   Serial.print("LeftEncoder: ");
    //   Serial.print(leftCounts);
    //   Serial.print("\tRightEncoder: ");
    //   Serial.print(rightCounts);
    //   Serial.print("\tLeftControl: ");
    //   Serial.print(adjustedLeftControl);
    //   Serial.print("\tRightControl: ");
    //   Serial.print(adjustedRightControl);
    //   Serial.print("\tcontrolDifference: ");
    //   Serial.print(controlDifference);
    //   Serial.print("\tDestination: ");
    //   Serial.println(endLocation);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

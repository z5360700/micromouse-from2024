# Micromouse
Template for the MTRN3100 Micromouse group assignment


// testing git push and pull
// this is my submission 28/june michael

This repository contains different folders, with each folder serving a different purpose in the code. 
